import {Component} from '@angular/core';

@Component({
    selector: 'pricing',
    templateUrl: 'app.pricing.html'
})

export class PricingComponent{}