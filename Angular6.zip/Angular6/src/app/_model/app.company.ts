export class Company{

    companyId:number;
    email:string;
    password:string;
    companyName:string;
    companyAddress:string;

}