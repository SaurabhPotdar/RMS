export class Qualification{

    qualificationId:number;
    cgpa:number;
    degree:string;

}