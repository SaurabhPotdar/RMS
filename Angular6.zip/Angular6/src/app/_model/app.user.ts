export class User{
  
    userId:number;
    firstName:string;
    email:string;
    password:string;
    position:string;
    experience:number;
    phoneNumber:string; 
    
}