import {Component} from '@angular/core';

@Component({
    selector: 'blog-single',
    templateUrl: 'app.blogsingle.html'
})



export class BlogSingleComponent  {

}