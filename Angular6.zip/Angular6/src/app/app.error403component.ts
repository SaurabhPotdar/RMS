import {Component} from '@angular/core';

@Component({
    selector:'forbidden',
    templateUrl:'app.error403.html'
})
export class Error403Component{

}