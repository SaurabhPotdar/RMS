export class Login{

    role:string;
    userId:number;

}