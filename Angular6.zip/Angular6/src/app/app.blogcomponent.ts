import {Component} from '@angular/core';

@Component({
    selector: 'blog',
    templateUrl: 'app.blog.html'
})



export class BlogComponent  {

}