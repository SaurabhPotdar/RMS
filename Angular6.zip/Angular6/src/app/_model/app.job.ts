
export class Job{

    jobId:number;
    designation:string;
    qualification:string;
    experience:number;
    salary:number;
    location:string;

}